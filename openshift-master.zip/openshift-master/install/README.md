https://cloud.redhat.com/openshift/install

https://mirror.openshift.com/pub/openshift-v4/clients/ocp/latest/
