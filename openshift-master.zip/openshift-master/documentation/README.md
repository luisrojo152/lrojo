https://access.redhat.com/documentation/en-us/openshift_container_platform/4.3/

https://kubernetes.io/docs/home/
